
---LICENSE---

This pack is free for personal and comercial projects as long as it's atributed to DANI MACCARI.

You are free to edit the sprites.
You should not repackage, redistribute or resell the assets, no matter how much they are modified. - This includes NFTs.


---HOW TO USE---

each sprite is 32x32 px

This asset pack contains 15 items divided by rows:

1 coin
1 heart
1 amo
2 boxes
2 gems
1 star
1 rainbow ball
3 keys


---THANK U---

Thank you for downloading my animation sprite pack :) i really apreciate it, hope you like it and find it usefull

There exists a character animation pack on this style. (TiM - FREE Character Animations)
In the near future i will update a tileset with the same art style

i will keep creating assets itch.io - @danimaccari -> https://dani-maccari.itch.io/

